package projectd;

public class Message {
	private String _message;
	public Doolhof _unnamed_Doolhof_;

	public void show() {
		throw new UnsupportedOperationException();
	}
}