package projectd;

import java.awt.Insets;

public class Valsspeler extends Pickup {

    

	public void resetTimer() {
		throw new UnsupportedOperationException();
	}
}