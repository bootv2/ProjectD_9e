package projectd;

import java.awt.Insets;

public class Helper extends Pickup {

  

	public void zoekRoute() {
		throw new UnsupportedOperationException();
	}
}