package projectd;

import java.awt.Insets;

public class Bazooka extends Pickup {

    
}