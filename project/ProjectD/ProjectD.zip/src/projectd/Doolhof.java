package projectd;

import java.util.Vector;

public class Doolhof {
	private boolean _isPaused;
	public Vector<Veld> _unnamed_Veld_ = new Vector<Veld>();
	public Vector<Knop> _unnamed_Knop_ = new Vector<Knop>();
	public Message _unnamed_Message_;

	public void draw() {
		throw new UnsupportedOperationException();
	}

	public void update() {
		throw new UnsupportedOperationException();
	}

	public void startGame() {
		throw new UnsupportedOperationException();
	}

	public void setPaused(boolean aState) {
		_isPaused = aState;
	}

	public void endGame() {
		throw new UnsupportedOperationException();
	}

	public void nextLevel() {
		throw new UnsupportedOperationException();
	}

	public void restart() {
		throw new UnsupportedOperationException();
	}
}