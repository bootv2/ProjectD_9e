package projectd;



/*public class Rocket implements BeweegbaarElement {
	public Muur _vernietigd;
	public Speler _unnamed_Speler_;

	public void explode() {
		throw new UnsupportedOperationException();
	}

	public void update() {
		throw new UnsupportedOperationException();
	}
}*/