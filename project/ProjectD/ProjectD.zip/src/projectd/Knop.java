package projectd;


import javax.swing.ImageIcon;



public class Knop {
	private ImageIcon _sprite;
	private int _functie;
	public Doolhof _unnamed_Doolhof_;
}