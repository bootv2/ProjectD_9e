package projectd;

import java.awt.Insets;

public class Vriend extends Pickup {
	public Veld _unnamed_Veld_;
	public Speler _unnamed_Speler_;
	public Item _unnamed_Item_;


	public void voltooiLevel() {
		throw new UnsupportedOperationException();
	}
}