package projectd;

import java.awt.event.KeyListener;

public interface BestuurbaarElement extends KeyListener {

	public void update();
}