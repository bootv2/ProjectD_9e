This is the JSFML test release as of December 2nd, 2013.

The platforms supported are Windows and Linux each 32 and 64 bit.
Java 7 is required.

Run jsfml-test.jar for a quick test of functionality.

http://jsfml.org/
